package store;
import java.util.*;
import java.io.*;

public abstract class scoring {

//variables
    static String line;
    public String player;


    // USER INFO //for not writing the code to get user info //we are using
    // inheritence
   

    public abstract void GAmeStarts();


    public void userinfo() {
        System.out.println("ENTER YOUR NAME");
        Scanner sc = new Scanner(System.in);
        player = sc.next();
    }


    public void storescore(String player) throws Exception {
            List<String> lines = new ArrayList<>();
            boolean playerExists = false;
            BufferedReader reader = new BufferedReader(new FileReader("scores.txt"));

            while ((line = reader.readLine()) != null) {
            String[] parts = line.split(":"); //Split the line with :

            if (parts.length == 2) {
                String name = parts[0];   //part before:==parts[0]
                int score = Integer.parseInt(parts[1]);

                if (name.equals(player)) {
                    score += 1; // Increment the score by 1
                    line = name + ":" + score; // Update the line with the new score
                    playerExists = true;
                }

                lines.add(line);
            }
            
        }



        // If the player doesn't exist, add a new entry with a score of 1
        if (!playerExists) {
            lines.add(player + ":1");
        }
        String filePath = "scores.txt";
        // Write all scores back to the file
        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
        for (String line : lines) {
            writer.write(line + "\n");
            writer.flush();

        }

    }
}
