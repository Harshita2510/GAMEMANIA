package tictactoe;

import java.util.Scanner;
import store.scoring;

public class TicTacToe extends scoring {
    // PRINT BOARD
    // TTT BOARD PRINTING
    String playerx;
    String playero;


    public void userinfo() {
        System.out.println("ENTER YOUR NAME ,Playerx");
        Scanner sc = new Scanner(System.in);
        playerx = sc.next();
        System.out.println("ENTER YOUR NAME ,Playero");
        playero = sc.next();
    }

    public void GAmeStarts() {
        System.out.println("Tic Tac toe Starts");
    }


    // print board
    private static void printBoard(char[] board) { // PARAMETER IN PRINT BOARD IS TAKING ARRAY
        System.out.println(" " + board[0] + " | " + board[1] + " | " + board[2]);
        System.out.println("-----------");
        System.out.println(" " + board[3] + " | " + board[4] + " | " + board[5]);
        System.out.println("-----------");
        System.out.println(" " + board[6] + " | " + board[7] + " | " + board[8]);
    }


    // winner funCTION
    private static boolean winner(char[] board, char player) {
        int[][] win = {
                // horizonal array conditions for winning
                { 0, 1, 2 }, { 3, 4, 5 }, { 6, 7, 8 }, // Horizontal
                { 0, 3, 6 }, { 1, 4, 7 }, { 2, 5, 8 }, // Vertical
                { 0, 4, 8 }, { 2, 4, 6 } // Diagonal
        };
        for (int[] condition : win) {
            if (board[condition[0]] == player && board[condition[1]] == player && board[condition[2]] == player) {
                return true;
            }
        }
        return false;
    }

    
    // DRAW FUBNCTION
    private static boolean draw(char[] board) {
        for (char cell : board) {
            if (cell == ' ') {
                return false;
            }
        }
        return true;
    }


    // START EXPLAINING CODE FROM HERE
    // GET INPUT
    public void getinput() throws Exception {
        Scanner sc = new Scanner(System.in);
        char[] board = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' }; // ARRAY INITIALIZE
        char player = 'X';
        while (true) {
            printBoard(board); // PRINT BOARD FUNCTION CALLED //PASSED ARRAY AS PARAMETER
            System.out.println("Player " + player + ", choose a position from 1 to 9:");
            int index;
            int cnt = 0;
            index = sc.nextInt() - 1; // -1 BECAUSE ARRAY INTIALIZE FROM ZERO
            if (index < 0 || index > 8) {
                System.out.println("Invalid position. Please choose a number between 1 and 9.");
                cnt = cnt + 1;
                continue;
            }
            if (board[index] != ' ') {
                System.out.println("Position already taken. Choose another position.");
                cnt = cnt + 1;
                continue;
            }
            if (cnt > 1) {
                System.out.println("Invalid input. Please enter a number between 1 and 9.");
                sc.next(); // clear the invalid input
                continue;
            }
            board[index] = player;
            if (winner(board, player)) { // WINNER FUNCTION CALLED
                printBoard(board); // PRINT BOARD FUNCTION CALLED
                System.out.println("Player " + player + " wins!");
                if (player == 'X') {
                    storescore(playerx);
                } else {
                    storescore(playero);
                }
                break;
            }
            if (draw(board)) { // DRAW FUNCTION CALLED
                printBoard(board); // PRINT BOARD FUNCTION CALLED
                System.out.println("It's a draw!");
                break;
            }
            if (player == 'X') {
                player = 'O';
            } else {
                player = 'X';
            }
        }
    }

}
