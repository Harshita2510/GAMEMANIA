package leader;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;



public class LeadrBoard {

   // public static void main(String[] args) {

public static void ld(){
               
        System.out.println("!!!!LEADERBoard!!!!");
        String fileName = "scores.txt"; // Replace with your file path

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }
}
