public class t{
    public static void main(String[] args) {
        front ty=new front();
    }
}