package rocpapsci;
import store.scoring;
import java.util.*;


//CHILD CLASS
public class RPS extends scoring {
   int n; //number of rounds
   private static int pscore, cscore,count;


    //NO OF ROUNDS
        public void getnumrounds() {
           Scanner Sc = new Scanner(System.in);
           System.out.println("Enter number of rounds");
        n = Sc.nextInt();
    }


    //private variable so that no one externally can initialize its value to try to manipulate scores 
   //Encapsulation setter and getter method
   public int getpscore(){return pscore;}
   public int getcscore(){return cscore;}
   public int getcount(){return count;}
   //we have to set value to zero then not using setter method will work bcoz instance variable automatically get intialized by 0
   public void setpscore(int psc){pscore=psc;}
   public void setcscore(int csc){cscore=csc;}
   public void setcount(int cnt){pscore=cnt;}



//CONDITIONS
    public void letsplay() {
        for (int i = 0; i < n; i++) {
            Random r = new Random();
            Scanner Sc = new Scanner(System.in);
            // player one
            System.out.println("Input 1 for ROCK");
            System.out.println("Input 2 for PAPER");
            System.out.println("Input 3 for SCISSOR");
            int ch1;
            ch1 = Sc.nextInt();
            // player 2
            int ch2;
            ch2 = r.nextInt(3) + 1;
            System.out.println("computer input is: " + ch2);

            if (ch1 == ch2) {
                System.out.println("It's a tie!!");

            } else if (ch1 == 1 && ch2 == 3) {
                System.out.println("You win");
                pscore++;
            } else if (ch1 == 2 && ch2 == 1) {
                System.out.println("You win");
                pscore++;
            } else if (ch1 == 3 && ch2 == 2) {
                System.out.println("You win");
                pscore++;
            } else {
                System.out.println("Computer wins");//if anything except 1,2,3 is entered then by default computer wins
                cscore++;
            }
            System.out.println();
        }
    }



         //FINAL SCORE
    public void finalscore() throws Exception {
        System.out.println("your final score is:" + pscore + " out of" + n);
        if (pscore > cscore){
            System.out.println("YOU WIN!!!!");
            count++;
        }
        else if (pscore == cscore) {

            System.out.println("IT'S A TIE");
        } else
            System.out.println("COMPUTER WINS...");
           if(count==1){
            storescore(player);
           }
}


    @Override
    public void GAmeStarts() {
      System.out.println("Rock Paper Scissor Starts");
    }
    
}

