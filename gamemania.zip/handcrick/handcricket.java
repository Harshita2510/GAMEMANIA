package handcrick;
import store.scoring;
import java.util.*;


public class handcricket extends scoring {
    private int sumPlayer ;
    private int sumComp = 0;
    private int n = 0;
    private int p = 0;
    private int count = 0;
    private int count1 = 0;
    //String player1;


    Random r = new Random();
    Scanner sc = new Scanner(System.in);



    public int getsump(){return sumPlayer;}
       public int getsumc(){return sumComp;}
       public int getn(){return n;}
       public int getp(){return p;}
       public int getcount1(){ return count;}
       public int getcount2(){return count1;}
       public void setsump(int sump){sumPlayer=sump;}
    public void setsumc(int sumc){sumComp=sumc;}
       public void setn(int n1){n=n1;}
       public void setp(int p1){p=p1;}
       public void setcount1(int count1){count=count1;}
       public void setcount2(int count2){count1=count2;}
       
       
       
    // BATTING
    public void bat() {
        System.out.println("Its Your Turn to Bat.");

        while (count == 0) {

            int turn = sc.nextInt(6);
            n = r.nextInt(6);
            if (turn == n) {
                System.out.println("Out!!");
                System.out.println("Your score is: " + sumPlayer);
                count++;
            } else {
                sumPlayer = sumPlayer + turn;

            }
        }
    }



    // BALLING
    public void ball() {
        System.out.println("Its Your Turn to Ball.");
        while (count1 == 0) {

            p = r.nextInt(6);
            int turn = sc.nextInt();
            if (turn == p) {
                System.out.println("Out!!");
                count1++;
            } else {
                sumComp = sumComp + p;
                if (sumComp > sumPlayer) {
                    System.out.println("Computer Wins.");
                    count1++;
                    System.out.println("Computer score is: " + sumComp);
                }
            }
        }
    }



    public void result() throws Exception {

        if (sumPlayer > sumComp) {
            System.out.println("You Win.");
            System.out.println("Your score is: " + sumComp);
        }
         storescore(player);
    }


    @Override
    public void GAmeStarts() {
       
            System.out.println("HandCricket Starts");
          
    }
}
