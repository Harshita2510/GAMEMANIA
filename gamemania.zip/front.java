import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import rocpapsci.*;
import leader.LeadrBoard;
import handcrick.handcricket;
import javax.swing.*;
import tictactoe.TicTacToe;

public class front implements ActionListener {
JFrame frame=new JFrame();
//label
JLabel label=new JLabel();//1st
JLabel labe=new JLabel();//3rd
JLabel lab=new JLabel();//2nd
JLabel la=new JLabel();//4rth game mania
//panels
JPanel rockps=new JPanel();
JPanel tictt =new JPanel();
JPanel cric =new JPanel();
JPanel gm=new JPanel();
//buttons
JButton b1=new JButton();
JButton b2=new JButton();
JButton b3=new JButton();


public front(){
    //main frame
    frame.setLayout(null);
frame.setSize(1066,1066);
frame.setTitle("RPS");
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setVisible(true);
ImageIcon im=new ImageIcon("ic.jpg");
frame.setIconImage(im.getImage());
frame.getContentPane().setBackground(new Color(0XDEE3FF));
//label
label.setText("ROCK PAPER SCISSOR");
ImageIcon image=new ImageIcon("giip.gif");
label.setIcon(image);
label.setHorizontalTextPosition(JLabel.CENTER);
label.setVerticalTextPosition(JLabel.TOP);
label.setVerticalAlignment(JLabel.TOP);
label.setHorizontalAlignment(JLabel.LEFT);
label.setIconTextGap(25);
label.setBounds(60,10,350,350);
//panel
rockps.setBackground(new Color(0XD4FFEA));
rockps.setBounds(0,181,350,350);
frame.add(rockps);
rockps.add(label);
rockps.setLayout(null);
//button
b1.setBounds(116, 280, 116, 50);
b1.setText("ROCK PAPER SCISSOR");
b1.setFocusable(false);

    // Existing code...

    b1.addActionListener(this);
    b2.addActionListener(this);
    b3.addActionListener(this);

    // Existing code...
rockps.add(b1);

//label2
lab.setText("TIC TAC TOE");
ImageIcon imag=new ImageIcon("icf.gif");
lab.setIcon(imag);
lab.setHorizontalTextPosition(JLabel.CENTER);
lab.setVerticalTextPosition(JLabel.TOP);
lab.setVerticalAlignment(JLabel.TOP);
lab.setHorizontalAlignment(JLabel.CENTER);
lab.setIconTextGap(25);
lab.setBounds(0,5,350,350);
//panel3
tictt.setBackground(new Color(0XFEFFA3));
tictt.setBounds(481,181,350,350);
frame.add(tictt);
tictt.setLayout(null);
tictt.add(lab);

//button
b2.setBounds(116, 280, 116, 50);
b2.setText("TIC TAC TOE");
b2.setFocusable(false);
//exsisting
tictt.add(b2);


//label3
labe.setText("HAND CRICKET");
ImageIcon ima=new ImageIcon("E5UD.gif");
labe.setIcon(ima);
labe.setHorizontalTextPosition(JLabel.CENTER);
labe.setVerticalTextPosition(JLabel.TOP);
labe.setVerticalAlignment(JLabel.TOP);
labe.setHorizontalAlignment(JLabel.RIGHT);
labe.setIconTextGap(25);
labe.setBounds(-30,6,350,350);
//panel3
cric.setBackground(new Color(0XFFD4E5));
cric.setBounds(961,181,350,350);
cric.setLayout(null);
frame.add(cric);
cric.add(labe);
//button
b3.setBounds(116, 280, 116, 50);
b3.setText("HAND CRICKET");
b3.setFocusable(false);

cric.add(b3);


//label 4
//panel 4
la.setText("!!!!GAME MANIA!!!!");
la.setHorizontalTextPosition(JLabel.CENTER);
la.setVerticalTextPosition(JLabel.CENTER);
la.setFont(new Font("Times New Roman", 0, 50));
gm.setBackground(new Color(0XEECBFF));
gm.setBounds(0,0,1340,100);
frame.add(gm);
gm.add(la);


}
@Override
public void actionPerformed(ActionEvent e) {
    if(e.getSource()==b1){
        RPS Player = new RPS();
        Player.GAmeStarts();
        Player.getpscore(); Player.getcscore();Player.getcount();
        Player.userinfo();
        Player.getnumrounds();
        Player.letsplay();
        try {
            Player.finalscore();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        LeadrBoard.ld();
        
    }
    else if(e.getSource()==b2){
        TicTacToe game = new TicTacToe();
        game.GAmeStarts();
        game.userinfo();
        try {
            game.getinput();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        LeadrBoard.ld();
        
    }
    else if(e.getSource()==b3){
        handcricket nonplay=new handcricket();
        nonplay.GAmeStarts();
        nonplay.setsump(0);nonplay.setsumc(0);nonplay.setn(0);nonplay.setp(0);nonplay.setcount1(0);nonplay.setcount2(0);
        nonplay.getsump();nonplay.getsumc();nonplay.getn();nonplay.getp();nonplay.getcount1();nonplay.getcount2();
        nonplay.userinfo();
        nonplay.bat();
        nonplay.ball();
        try {
            nonplay.result();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        LeadrBoard.ld();
        
    }


}
    
}
